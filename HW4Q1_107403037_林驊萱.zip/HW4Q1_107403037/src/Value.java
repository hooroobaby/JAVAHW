import javax.swing.JFrame;
import javax.swing.JOptionPane;

//��ޤT_107403037_�L�~��


public class Value {
	public static void main (String args[]) {
		
		Main main = new Main();
		main.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		main.setSize(1200, 600);
		main.setVisible(true);
	}
}
