import java.io.IOException;

import javax.swing.JFrame;

public class Electric2 {
	public static void main(String[] args) throws IOException {
		Main main = new Main();
		((JFrame) main).setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		main.setSize(500, 500);
		main.setVisible(true);
	}
}
