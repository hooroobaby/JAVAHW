import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;

import javax.imageio.IIOException;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class Main extends JFrame {
	public static JLabel[] maplist = new JLabel[200]; // �ŧi�@�ӥi�˸�JLabel���}�C
//	String map = "";
	int[] array = new int[50];
	public static int i = 0;// ���@maplist�̭����}�C�Ѽ�
	public static Bloodpanel bloodpanel = new Bloodpanel();
	public static JPanel northpanel = new JPanel(new GridLayout(10, 10));

	public Main() throws IOException {
		// Ū�J�ɮ�
		try {
			Scanner scanner = new Scanner(new File("src\\map.txt"));
//			Scanner s = new Scanner(map);
//			int n = Integer.parseInt(s.next());

			/***** Funtional Programming *******/
			Arrays.stream(array).map(array -> Integer.parseInt(scanner.next())) // �NscannerŪ�쪺map��array��
					.forEach(array -> decide(array)); // �]�@��class�ΨӱNŪ�쪺�Ʀr���W��
			scanner.close();
			// �]�w�r��map�s��txt��readlineŪ�i�Ӫ����e
//			while (br.ready()) {
//				map += br.readLine() + "\n";
//			} //
//			fr.close();
		} catch (IOException ioException) {
			ioException.printStackTrace();
		}
		BorderLayout layout = new BorderLayout();

		add(bloodpanel, layout.SOUTH);
		add(northpanel, layout.NORTH);

//		while (s.hasNext())// ��Scanner�٦�Ū��map���F��(�N���٦��ϥ�)
//		{
		// xxxxxx �NScsnnerŪ��(��txt��L�Ӫ�)mapŪ�imaplist�}�C
	}

	public  void decide(int a)   {
		if (a == 0) {// �D��1
			maplist[i] = new JLabel(" ");// �Y��i��Ū�쪺�O0(�D��)�A�N�ťզs�J�}�C
			// ����\��
			maplist[i].addMouseListener(new MouseAdapter() {
				// handle event when mouse enters area
				@Override
				public void mouseEntered(MouseEvent e) {
					bloodpanel.blood(5 / 100 * 500);// 5/100*500
					repaint();
				}
			});
		}
		if (a == 1) {// ���

			int r = (int) (Math.random() * 5) + 1; // �إߤ@��1-5���ü�

			if (r == 4) // �Y�ü�=4�A�ܰ�
			{
				maplist[i] = new JLabel("", setghost(), SwingConstants.LEFT);
				// ����\��
				maplist[i].addMouseListener(new MouseAdapter() {
					// handle event when mouse enters area
					@Override
					public void mouseEntered(MouseEvent e) {
						bloodpanel.blood(100 / 100 * 500);// 100/100*500
						repaint();
					}
				});
			}

			else if (r == 2) // �Y=2�A�ܷR��
			{
				maplist[i] = new JLabel("", setheart(), SwingConstants.LEFT);
				// ����\��
				maplist[i].addMouseListener(new MouseAdapter() {
					// handle event when mouse enters area
					@Override
					public void mouseEntered(MouseEvent e) {
						bloodpanel.blood(-30 / 100 * 500);// -30/100*500
						repaint();
					}
				});
			}

			else// 1�B3�B5���O���
			{
				maplist[i] = new JLabel("", setbrickwall(), SwingConstants.LEFT);
				// ����\��
				maplist[i].addMouseListener(new MouseAdapter() {
					// handle event when mouse enters area
					@Override
					public void mouseEntered(MouseEvent e) {
						// bloodpanel.blood(20/100*500 );//20/100*500
						repaint();
					}
				});
			}
		}
			if (a == 2) {// �X�f
				maplist[i] = new JLabel("", setdiamond(), SwingConstants.LEFT);

				maplist[i].addMouseListener(new MouseAdapter() {
					// handle event when mouse enters area
					@Override
					public void mouseEntered(MouseEvent e) {
						// bloodpanel.blood(1);//20/100*500
						repaint();
					}
				});
			 }
		northpanel.add(maplist[i]);
		i++;
		// } // end while
	}

	// �]�w�j���Ϥ�()
	public static ImageIcon setbrickwall() {
		try {
			ImageIcon brickwall = new ImageIcon(ImageIO.read(new File("src\\brickwall.png")));
			Image image = brickwall.getImage();
			Image newimg = image.getScaledInstance(30, 30, java.awt.Image.SCALE_AREA_AVERAGING);
			brickwall = new ImageIcon(newimg);

			return brickwall;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	// �]�w�p�۹Ϥ�()
	public static ImageIcon setdiamond() {
		try {
			ImageIcon diamond = new ImageIcon(ImageIO.read(new File("src\\diamond.png")));
			Image image = diamond.getImage();
			Image newimg = image.getScaledInstance(50, 50, java.awt.Image.SCALE_AREA_AVERAGING);
			diamond = new ImageIcon(newimg);

			return diamond;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	// �]�w���Ϥ�()
	public static ImageIcon setghost() {
		try {
		ImageIcon ghost = new ImageIcon(ImageIO.read(new File("src\\ghost.png")));
		// �]�w�Ϥ��j�p
		Image image = ((ImageIcon) ghost).getImage(); // transform it
		Image newimg = image.getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH); // scale it the smooth way
		ghost = new ImageIcon(newimg); // transform it back
		return ghost;
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	// �]�w�R�߹Ϥ�()
	public static ImageIcon setheart()  {
		try {
		ImageIcon heart = new ImageIcon(ImageIO.read(new File("src\\heart.png")));
		// �]�w�Ϥ��j�p
		Image image = ((ImageIcon) heart).getImage(); // transform it
		Image newimg = image.getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH); // scale it the smooth way
		heart = new ImageIcon(newimg); // transform it back
		return heart;
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		return null;
	}
}
