//�L�~��_107403037_���3B
import javax.swing.*;

public class painter {
	public static void main(String[] args) {
		
		PainterFrame painterframe = new PainterFrame();
		((JFrame) painterframe).setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		painterframe.setSize(1200, 600);
		painterframe.setVisible(true);
	}
}
