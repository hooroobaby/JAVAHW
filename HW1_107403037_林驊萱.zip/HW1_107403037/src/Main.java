//�L�~��_107403037_���3B
import javax.swing.*;

public class Main {
	public static void main(String[] args) {
		
		MainFrame mainframe = new MainFrame();
		((JFrame) mainframe).setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainframe.setSize(2600, 1300);
		mainframe.setVisible(true);
	}
}

