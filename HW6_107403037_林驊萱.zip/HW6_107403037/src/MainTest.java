//��ޤT_107403037_�L�~��
import javax.swing.JFrame;

public class MainTest {
	// main method begins program execution
		public static void main(String[] args) {
			Main main = new Main();
			main.setSize(1000,800); 
		    main.setVisible(true); 
			main.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			main.setLocationRelativeTo(null); //�N�e���m��
		}
}
